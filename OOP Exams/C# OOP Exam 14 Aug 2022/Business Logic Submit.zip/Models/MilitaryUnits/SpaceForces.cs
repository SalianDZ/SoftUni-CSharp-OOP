﻿namespace PlanetWars.Models.MilitaryUnits
{
    public class SpaceForces : MilitaryUnit
    {
        private const double DefaultCost = 11;
        public SpaceForces() : base(DefaultCost)
        {
        }
    }
}
