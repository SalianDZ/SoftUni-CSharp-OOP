﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.Vehicles
{
    public abstract class Vehicle : IVehicle
    {

        private double increasedConsumption;
        protected Vehicle(double fuelQuantity, double fuelConsumptionPerKm, double increasedConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumptionPerKm = fuelConsumptionPerKm;
            this.increasedConsumption = increasedConsumption;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumptionPerKm { get; private set; }

        public string Drive(double distance)
        {
            double totalConsumption = FuelConsumptionPerKm + increasedConsumption;

            if (FuelQuantity < distance * totalConsumption)
            {
                throw new ArgumentException($"{this.GetType().Name} needs refueling");
            }
            FuelQuantity -= distance * totalConsumption;
            return $"{this.GetType().Name} travelled {distance} km";
        }

        public virtual void Refuel(double fuelAmount) => FuelQuantity += fuelAmount;

        public override string ToString() => $"{this.GetType().Name}: {FuelQuantity:F2}";
    }
}
