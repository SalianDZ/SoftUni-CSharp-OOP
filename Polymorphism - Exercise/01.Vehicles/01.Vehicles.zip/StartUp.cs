﻿using System.ComponentModel;

namespace _01.Vehicles
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] carTokens = Console.ReadLine().Split();
            string[] truckTokens = Console.ReadLine().Split();
            IVehicle car = new Car(double.Parse(carTokens[1]), double.Parse(carTokens[2]));
            IVehicle truck = new Truck(double.Parse(truckTokens[1]), double.Parse(truckTokens[2]));

            int commandsCount = int.Parse(Console.ReadLine());


            for (int i = 0; i < commandsCount; i++)
            {
                try
                {
                    string[] command = Console.ReadLine().Split();

                    if (command[0] == "Drive")
                    {
                        if (command[1] == "Car")
                        {
                            Console.WriteLine(car.Drive(double.Parse(command[2])));
                        }
                        else if (command[1] == "Truck")
                        {
                            Console.WriteLine(truck.Drive(double.Parse(command[2])));
                        }
                    }
                    else if (command[0] == "Refuel")
                    {
                        if (command[1] == "Car")
                        {
                            car.Refuel(double.Parse(command[2]));
                        }
                        else if (command[1] == "Truck")
                        {
                            truck.Refuel(double.Parse(command[2]));
                        }
                    }
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            Console.WriteLine(car.ToString());
            Console.WriteLine(truck.ToString());
        }
    }
}