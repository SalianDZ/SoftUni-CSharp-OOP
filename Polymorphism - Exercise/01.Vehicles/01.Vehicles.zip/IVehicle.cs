﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.Vehicles
{
    public interface IVehicle
    {
        public double FuelQuantity { get; }
        public double FuelConsumptionPerKm { get;}

        public string Drive(double distance);
        public void Refuel(double fuelAmount);
    }
}
