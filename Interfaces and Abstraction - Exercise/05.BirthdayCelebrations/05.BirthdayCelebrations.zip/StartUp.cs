﻿namespace PersonInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List <IBirthable> creatures = new();
            IBirthable currentCreature;

            while (true)
            {
                string[] tokens = Console.ReadLine().Split();

                if (tokens[0] == "End")
                {
                    break;
                }
                else if (tokens[0] == "Citizen")
                {
                    currentCreature = new Citizen(tokens[1], int.Parse(tokens[2]),
                        tokens[3], tokens[4]);
                    creatures.Add(currentCreature);
                }
                else if (tokens[0] == "Pet")
                {
                    currentCreature = new Pet(tokens[1], tokens[2]);
                    creatures.Add (currentCreature);
                }
            }
            string date = Console.ReadLine();

            foreach (var creature in creatures)
            {
                string currentDate = string.Empty;

                for (int i = 6; i < creature.Birthdate.Length; i++)
                {
                    currentDate += creature.Birthdate[i];
                }


                if (currentDate == date)
                {
                    Console.WriteLine(creature.Birthdate);
                }
            }
        }
    }
}